package org.example;


import java.util.Random;



public class GetToy {



    public int GetTotalWeight(Toy[] toyList) {
        int totalWeight = 0;
        for (Toy toy : toyList) {
            totalWeight += toy.getWeight();
        }

        return totalWeight;
    }

    public Toy[] GetToysMassive(Toy[] toylist, int totalWeight, int totalQuantity) {
        Random random = new Random();
        Toy[] toys = new Toy[totalQuantity];
        for (int i = 0; i < totalQuantity; i++) {
            int randomNumber = random.nextInt(totalWeight) + 1;
            int cumulativeWeight = 0;

            for (Toy toy : toylist) {
                cumulativeWeight += toy.getWeight();
                if (randomNumber <= cumulativeWeight) {
                    toys[i] = new Toy(toy.getId(), toy.getName(), toy.getWeight());
                    break;
                }
            }
        }
        return toys;
    }

}
