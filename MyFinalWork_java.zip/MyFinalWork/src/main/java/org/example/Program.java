package org.example;

import java.util.*;


public class Program {


    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int types = 0;
        try {
            System.out.println("Введите количество видов игрушек:");
            types = scanner.nextInt();
        } catch (InputMismatchException ex) {
            System.out.println("Некорректное количество " + ex);
        } catch (NumberFormatException e) {
            System.out.println("Некорректное количество ");
        }

        int number = 0;
        try {
            System.out.println("Введите общее количество игрушек:");
            number = scanner.nextInt();
        } catch (InputMismatchException ex) {
            System.out.println("Некорректное количество " + ex);
        } catch (NumberFormatException e) {
            System.out.println("Некорректное количество ");
        }


        Toy[] typesOfToys = PutToy.ToyListCreation(types).toArray(new Toy[0]);


        GetToy gettoy = new GetToy();
        int totalWeight = gettoy.GetTotalWeight(typesOfToys);
        Toy[] MyToyList = gettoy.GetToysMassive(typesOfToys, totalWeight, number);


        PriorityQueue<Toy> queue = new PriorityQueue<>();
        Collections.addAll(queue, MyToyList);
        ArrayList<Toy> toys = new ArrayList<Toy>();

        Toy currentToy = null;


        while ((currentToy = queue.poll()) != null) {
            toys.add(currentToy);
            System.out.println("--- Toy Weight: " + currentToy.getId() + " ---");
            System.out.println("--- Toy Name: " + currentToy.getName() + " ---");
            System.out.println("--- Toy Weight: " + currentToy.getWeight());
            System.out.println();

        }
        SaveToJson saveToJson = new SaveToJson();
        saveToJson.saving(toys);


    }

}