package org.example;


import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class SaveToJson {



    public void saving(ArrayList<Toy> toys) {
        String fileName = "toys.json";
        Toy currentToy;
        try (FileWriter writer = new FileWriter(fileName, false)) {

            for (Toy value : toys) {
                currentToy = value;
                writer.append("{\n");
                writer.append("\"ToyId\":\"").append(String.valueOf(currentToy.getId())).append("\",\n");
                writer.append("\"Name\":\"").append(currentToy.getName()).append("\",\n");
                writer.append("\"Weight\":").append(String.valueOf(currentToy.getWeight())).append(",\n");
                writer.append("}\n");
                writer.flush();
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }


}

