package org.example;

import java.util.ArrayList;


public class PutToy {


    public static ArrayList<Toy> ToyListCreation(int ammount) {
        ArrayList<Toy> toysList = new ArrayList<>();
        for (int i = 0; i < ammount; i++) {

            InputFromConsole inputFromConsole = new InputFromConsole();
            Toy toy = inputFromConsole.filling();
            toysList.add(toy);
        }
        return toysList;
    }


}
